import { useState } from 'react'
import './App.css'

import Component from './component/Component'

function App() {
  const [count, setCount] = useState(0)

  return (
    <div>
      <Component />
    </div>
  )
}

export default App
