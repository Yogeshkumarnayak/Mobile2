import { useState } from 'react'
import { Bell, Calendar, ChevronDown, Menu, Search, Settings, Plus, Phone, Mail, Lightbulb, Star, Lock, Users, BarChart, FileText, ArrowRight } from 'lucide-react'

export default function Component() {
  const [activeTab, setActiveTab] = useState('Activity')
  const [activeSection, setActiveSection] = useState('Other Contacts')

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Side Navigation */}
      <div className="w-16 bg-[#1a3a5a] flex flex-col items-center py-4 space-y-6">
        <div className="w-8 h-8 bg-red-500 rounded-md flex items-center justify-center text-white text-xl font-bold">
          D
        </div>
        <Star className="w-6 h-6 text-gray-400" />
        <Lock className="w-6 h-6 text-gray-400" />
        <Users className="w-6 h-6 text-gray-400" />
        <BarChart className="w-6 h-6 text-gray-400" />
        <FileText className="w-6 h-6 text-gray-400" />
      </div>

      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-[#1a3a5a] text-white p-2 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Menu className="h-6 w-6" />
            <h1 className="text-xl font-bold">Test</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Search className="h-5 w-5" />
            <Settings className="h-5 w-5" />
            <Bell className="h-5 w-5" />
            <Calendar className="h-5 w-5" />
            <div className="w-8 h-8 bg-blue-500 rounded-full"></div>
          </div>
        </header>

        {/* Breadcrumb */}
        <div className="bg-white p-2 text-sm">
          Dashboard / Lead / LE-010071
        </div>

        {/* Main Content */}
        <div className="flex-1 flex overflow-hidden">
          {/* Sidebar */}
          <aside className="w-64 bg-white border-r overflow-y-auto">
            <div className="p-4">
              <h2 className="text-2xl font-bold">LE-010071</h2>
              <div className="flex flex-wrap gap-2 mt-2">
                <span className="px-2 py-1 bg-orange-100 text-orange-600 rounded text-xs">New</span>
                <span className="px-2 py-1 bg-gray-200 text-gray-600 rounded text-xs">Contacted</span>
                <span className="px-2 py-1 bg-gray-200 text-gray-600 rounded text-xs">Nurturing</span>
                <span className="px-2 py-1 bg-gray-200 text-gray-600 rounded text-xs">Qualified</span>
                <span className="px-2 py-1 bg-gray-200 text-gray-600 rounded text-xs">Unqualified</span>
              </div>
              <div className="mt-4">
                <div className="flex items-center space-x-2">
                  <span className="w-2 h-2 bg-orange-400 rounded-full"></span>
                  <span className="text-orange-400 text-sm">Contacted</span>
                </div>
                <h3 className="text-lg font-semibold mt-2">Mamta Naik</h3>
                <div className="flex items-center space-x-2 mt-1">
                  <div className="w-6 h-6 bg-purple-500 rounded-full flex items-center justify-center text-white text-xs">A</div>
                  <span className="text-sm text-gray-600">Aniruddh Naidu</span>
                </div>
              </div>
            </div>
            <nav className="mt-4">
              {['Basic Details', 'Account Details', 'Lead Details', 'Team', 'Other Contacts'].map((item) => (
                <a
                  key={item}
                  href="#"
                  className={`block px-4 py-2 hover:bg-gray-100 ${
                    activeSection === item ? 'bg-gray-100 font-semibold' : ''
                  }`}
                  onClick={() => setActiveSection(item)}
                >
                  {item}
                </a>
              ))}
            </nav>
          </aside>

          {/* Main Area */}
          <main className="flex-1 p-6 overflow-y-auto">
          <div className="bg-white rounded-lg shadow mb-6">
            {/* Tabs */}
            <div className="flex border-b">
              {['Activity', 'Actionables', 'Tasks', 'Note & File'].map((tab) => (
                <button
                  key={tab}
                  className={`px-4 py-2 ${activeTab === tab ? 'border-b-2 border-blue-500 text-blue-500' : ''}`}
                  onClick={() => setActiveTab(tab)}
                >
                  {tab}
                </button>
              ))}
              <div className="ml-auto px-4 py-2">
                <button className="px-4 py-1 bg-blue-500 text-white rounded flex items-center">
                  Mark as Converted <ArrowRight className="ml-2 h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Tab Content */}
            <div className="p-4">
              {activeTab === 'Activity' && (
                <div className="space-y-4">
                  <div className="flex space-x-4">
                    <button className="flex items-center space-x-2 px-4 py-2 border rounded">
                      <Phone className="h-4 w-4" />
                      <span>Log a Call</span>
                    </button>
                    <button className="flex items-center space-x-2 px-4 py-2 border rounded">
                      <Mail className="h-4 w-4" />
                      <span>Email</span>
                    </button>
                    <button className="flex items-center space-x-2 px-4 py-2 border rounded">
                      <Lightbulb className="h-4 w-4" />
                      <span>Event</span>
                    </button>
                  </div>
                  <div className="space-y-2">
                    <input type="text" placeholder="Subject" className="w-full p-2 border rounded" />
                    <div className="flex space-x-2">
                      <input type="text" placeholder="Add People" className="flex-1 p-2 border rounded" />
                      <input type="date" className="p-2 border rounded" />
                      <input type="time" className="p-2 border rounded" />
                    </div>
                    <textarea placeholder="Description" className="w-full p-2 border rounded" rows={4}></textarea>
                  </div>
                  <div className="flex justify-between items-center">
                    <button className="px-4 py-2 border rounded text-gray-600">Add Team Member</button>
                    <button className="px-4 py-2 bg-blue-500 text-white rounded">Submit</button>
                  </div>
                </div>
              )}
            </div>
          </div>


            {/* Stage History */}
            <div className="bg-white rounded-lg shadow p-4 mb-6">
              <h3 className="text-lg font-semibold mb-4">Stage History</h3>
              <div className="space-y-4">
                {[
                  { date: '28/08', time: '09:00am', type: 'Team', action: 'Created Jiya Gopal' },
                  { date: '28/08', time: '10:00am', type: 'Team', action: 'Assigned to Aniruddh Naidu' },
                  { date: '28/08', time: '12:00pm', type: 'Event', action: 'Arrange a Call' },
                  { date: '28/08', time: '04:00pm', type: 'Lead Update', action: 'Marked as Contacted' },
                ].map((item, index) => (
                  <div key={index} className="flex items-center space-x-4">
                    <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                    <span className="text-sm font-medium">{item.date}</span>
                    <span className="text-sm text-gray-600">{item.type} | {item.time}</span>
                    <span className="text-sm">{item.action}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Upcoming & Overdue */}
            <div>
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">Upcoming & Overdue</h3>
                <a href="#" className="text-blue-500 text-sm">View All</a>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
                  { icon: Phone, title: 'Arrange a Call', start: '27/08/2024', end: '27/08/2024', startTime: '12:00pm', endTime: '01:00pm' },
                  { icon: Mail, title: 'Follow Up Email', start: '27/08/2024', end: '27/08/2024', startTime: '02:00pm', endTime: '03:00pm' },
                  { icon: Phone, title: 'Arrange a Call', start: '28/08/2024', end: '28/08/2024', startTime: '10:00am', endTime: '10:30am' },
                ].map((event, index) => (
                  <div key={index} className="bg-white rounded-lg shadow p-4">
                    <div className="flex items-center space-x-2 mb-2">
                      <event.icon className="h-4 w-4 text-gray-500" />
                      <span className="font-medium">{event.title}</span>
                    </div>
                    <div className="text-sm text-gray-600">
                      <div>Start: {event.start}</div>
                      <div>End: {event.end}</div>
                      <div>{event.startTime} - {event.endTime}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  )
}